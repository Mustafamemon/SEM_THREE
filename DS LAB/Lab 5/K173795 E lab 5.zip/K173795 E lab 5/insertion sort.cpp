#include<iostream>
using namespace std;

int* insertionsort(int *ptr , int size)
{
	int value,j;
	for(int i=1;i<size;i++)
	{
		value=ptr[i];
		for(j=i;j>0 && ptr[j-1]>value;j--)
		{
			ptr[j]=ptr[j-1];
		}
		if(i!=j)
		ptr[j]=value;
	}
	return ptr;
}
int main()
{
	int arr[] = {9,5,3,1,2,0,8,1};
	int size=sizeof(arr)/sizeof(arr[0]);
	for(int i=0;i<size;i++)
	{
		cout<<arr[i]<<" ";
	}
	cout<<endl;
	int *ptr1=insertionsort(arr,size);
	for(int i=0;i<size;i++)
	{
		cout<<ptr1[i]<<" ";
	}
}
