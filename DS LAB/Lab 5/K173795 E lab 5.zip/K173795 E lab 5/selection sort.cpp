#include<iostream>
using namespace std;

void swap1(int &a , int &b)
{
	int temp;
	temp=a;
	a=b;
	b=temp;
}

int* selectionsort(int *ptr , int size)
{
	int flag=0;
	int min;
	for(int i=0;i<size-1;i++)
	{
		min=i;
		for(int j=i+1;j<size;j++)
		{
			if(ptr[j]<ptr[min])
			{
				min=j;
			}
		}
		if(ptr[i]!=ptr[min])
		swap1(ptr[i],ptr[min]);
	}
	return ptr;
}
int main()
{
	int arr[] = {9,5,3,1,2};
	int size=sizeof(arr)/sizeof(arr[0]);
	int *ptr1=selectionsort(arr,size);
	for(int i=0;i<size;i++)
	{
		cout<<ptr1[i]<<" ";
	}
}
