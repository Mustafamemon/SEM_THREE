#include<iostream>
using namespace std;

void swap1(int &a , int &b)
{
	int temp;
	temp=a;
	a=b;
	b=temp;
}

int* bubblesort(int *ptr , int size)
{
	int flag=0;
	for(int i=0;i<size;i++)
	{
		for(int j=0;j<size-(i+1);j++)
		{
			if(ptr[j]>ptr[j+1])
			{
				flag=1;
				swap1(ptr[j],ptr[j+1]);
			}
		}
		if(flag==0)
		break;
	}
	return ptr;
}
int main()
{
	int arr[] = {1,0,3,4,5,8,3,1};
	int size=sizeof(arr)/sizeof(arr[0]);
	int *ptr1=bubblesort(arr,size);
	for(int i=0;i<size;i++)
	{
		cout<<ptr1[i]<<" ";
	}
}
