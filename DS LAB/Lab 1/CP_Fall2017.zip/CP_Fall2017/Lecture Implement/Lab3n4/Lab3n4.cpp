#include<iostream>

using namespace std;

class Student
{
	int  id;
	public:
		string name;
		Student()
		{
			id = 100;
			name = "\0";
		}
		Student(int i)
		{
			id = i;
			name="\0";
		}
		void setId(int i)
		{
			id = i;
		}
		int getId()
		{
			return id;
		}
		void print()
		{
			cout<<"Student ID: "<<id<<endl;
			cout<<"Student Name: "<<name<<endl;
		}
		~Student()
		{
			cout<<"Destrucctor Called"<<endl;
		}
	
};


int main()
{
	Student s;
	cout<<"Student S Default Value: "<<endl;
	s.print();
	cout<<"Enter Student ID: ";
	int i = 0;
	cin>>i;
	s.setId(i);
	cout<<"Enter Student Name: ";
	cin>>s.name;
	cout<<"Student ID: "<<s.getId()<<endl;
	cout<<"Student Name: "<<s.name<<endl;
	Student s1;
	s1.print();
	Student s2(25);
	s2.print();

}
