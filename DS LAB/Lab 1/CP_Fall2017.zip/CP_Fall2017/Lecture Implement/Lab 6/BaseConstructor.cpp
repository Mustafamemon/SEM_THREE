#include<iostream>
using namespace std;
class A{
	private:
		int a;
	public:
		A(int c)
		{
			a= c;
		}
	void showData()
	{
		cout<<a<<endl;
	}
};
class C{
	private:
		int c;
	public:
		C(int a)
		{
			c= a;
		}
	void showData()
	{
		cout<<c<<endl;
	}
};
class B : public A, public C{
	private:
		int b;
		public:
			B(int a, int bv,int cv):A(a),C(cv)
			{
				b=bv;
			}
			void show()
			{
				A::showData();
				C::showData();
				cout<<b;
			}
};
main()
{
	B b(5,10,6);
	b.show();
}
